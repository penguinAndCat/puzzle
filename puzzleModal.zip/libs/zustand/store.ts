import create from 'zustand';

export const useModal = create<ModalPros>((set) => ({
  modalDisplay: true,
  offModal: () => set({ modalDisplay: false }),
  onModal: () => set({ modalDisplay: true }),
}));
