import { useModal } from 'libs/zustand/store';
import { useEffect } from 'react';
import styled from 'styled-components';

const Modal = () => {
  const { offModal } = useModal();

  const closeModal = (
    e: React.MouseEvent<HTMLDivElement, MouseEvent> | React.MouseEvent<SVGSVGElement, MouseEvent>
  ) => {
    e.preventDefault();
    document.body.style.overflow = 'unset';
    offModal();
  };

  useEffect(() => {
    document.body.style.overflow = 'hidden';
  }, []);

  return (
    <>
      <OuterContainer onClick={closeModal} />
      <Container>
        <div>
          <img src="cp2.png" />
        </div>
        <div>방이름</div>
        <div>퍼즐 수</div>
      </Container>
    </>
  );
};

export default Modal;

const OuterContainer = styled.div`
  position: fixed;
  top: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.2);
`;

const Container = styled.div`
  @keyframes fadein {
    0% {
      transform: scale(1);
      opacity: 0;
      transform: translate3d(-50%, -100%, 0);
    }
    50% {
      transform: scale(1);
      opacity: 1;
      transform: translate3d(-50%, -45%, 0);
    }
    100% {
      transform: scale(1);
      opacity: 1;
      transform: translate3d(-50%, -50%, 0);
    }
  }
  animation: fadein 0.5s;

  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate3d(-50%, -50%, 0);
  width: 600px;
  height: 600px;
  background-color: ${({ theme }) => theme.bgColor};
`;

const Wrapper = styled.div``;
